/* Cal Sailing Club 3D Map: service worker. It sits next to the map page and keeps the installed app usable
   on a weak or missing connection, without getting in the way of anything else on the site.
   - The map page: fetched fresh each time so members get the latest version. If the network fails, or takes
     more than 5 seconds, the last copy opens instead.
   - The app's own files: fetched when the app is installed or updated, then kept. The code files (app, areas, map3d)
     and the map library have a version in their names, so a copy never goes out of date: a new version of the site
     has new names, and a new sw.js, which fetches them and drops the old copies.
   - Map data (aerial photos, NOAA chart, terrain, base map tiles and fonts): a tile downloaded in the last
     month is reused without asking the network. Once it's older than that, it's downloaded again the next
     time it's needed, and the old copy is used if the signal is too weak. So the areas you've looked at in
     the past month still show when the signal drops on the water. See mapData() for the limits.
   - Everything else, including live wind and analytics, goes straight to the network as usual. */
// Written by build.py: VERSION changes with every build that changes the code, so browsers pick up the new files.
// (v2: icons in the club logo's colours; v3: map tiles kept for a month; v4: index.html, icons beside it; v5: new icons;
// v6: last good page when the server sends an error; v7: code in separate files, map library on this site)
var VERSION = 'v7-5d68fc5772';
var SHELL = 'csc-map-shell-' + VERSION, TILES = 'csc-map-tiles', PAGE_WAIT_MS = 5000;
var scope = self.registration.scope;
var PAGE = new URL(new URL(self.location.href).searchParams.get('page') || 'index.html', scope).href;
// The page answers both as index.html and as the folder itself (https://map.cal-sailing.org/)
var PAGE_PATHS = [new URL(PAGE).pathname].concat(/\/index\.html$/.test(PAGE) ? [new URL(scope).pathname] : []);
// The app's files, beside sw.js (written by build.py)
var OWN = ["manifest.webmanifest", "icon-192.png", "icon-512.png", "maskable-192.png", "maskable-512.png", "apple-touch-icon.png", "favicon-32.png", "favicon.svg", "csc-logo.png", "js/app.a02711586c.js", "js/areas.6e038000a3.js", "js/map3d.fde144fab1.js", "lib/maplibre-gl-5.24.0/maplibre-gl.js", "lib/maplibre-gl-5.24.0/maplibre-gl.css"].map(function (p) { return new URL(p, scope).href; });

function isMapData(u) {
  var h = u.hostname;
  if (h === 'tiles.openfreemap.org' || h === 'basemap.nationalmap.gov' || h === 'imagery.nationalmap.gov' || h === 'gis.charttools.noaa.gov') return true;
  return h === 's3.amazonaws.com' && u.pathname.indexOf('/elevation-tiles-prod/') === 0;
}

// Fetch with a time limit, so a slow or unreachable server never holds up installing
function fetchT(u, ms) {
  var ctl = typeof AbortController === 'function' ? new AbortController() : null, t = ctl && setTimeout(function () { ctl.abort(); }, ms);
  return fetch(u, { cache: 'reload', mode: 'cors', signal: ctl ? ctl.signal : undefined }).then(function (r) { clearTimeout(t); return r; }, function (e) { clearTimeout(t); throw e; });
}
self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(SHELL).then(function (c) {
    return Promise.all([PAGE].concat(OWN).map(function (u) {
      return fetchT(u, 10000).then(function (r) { if (r.ok) return c.put(u, r); }).catch(function () { /* picked up on a later visit instead */ });
    }));
  }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k.indexOf('csc-map-shell-') === 0 && k !== SHELL; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var u = new URL(req.url);
  if (req.mode === 'navigate') {
    if (u.origin === self.location.origin && PAGE_PATHS.indexOf(u.pathname) > -1) e.respondWith(pageFirst(req));
    return;
  }
  if (u.origin === self.location.origin && OWN.indexOf(u.origin + u.pathname) > -1) { e.respondWith(cacheFirst(req)); return; }
  if (isMapData(u)) e.respondWith(mapData(e, req, u));
});

// The page: network first, falling back to the last good copy if the network fails, is very slow, or the server
// answers with an error page (a 404 or 500 while the site is being updated, say)
function pageFirst(req) {
  var cached = caches.open(SHELL).then(function (c) { return c.match(PAGE); });
  var net = fetch(req).then(function (r) {
    if (r.ok) { var copy = r.clone(); caches.open(SHELL).then(function (c) { return c.put(PAGE, copy); }); }
    return r;
  });
  return new Promise(function (resolve) {
    var done = false;
    function finish(r) { if (!done && r) { done = true; resolve(r); } }
    var t = setTimeout(function () { cached.then(finish); }, PAGE_WAIT_MS);
    net.then(function (r) {
      clearTimeout(t);
      if (r.ok || r.type === 'opaqueredirect') finish(r);
      else cached.then(function (c) { finish(c || r); });   // no copy yet: show the server's answer after all
    }, function () {
      clearTimeout(t);
      cached.then(function (c) { finish(c || Response.error()); });
    });
  });
}

function cacheFirst(req) {
  return caches.match(req, { ignoreSearch: true }).then(function (hit) {
    return hit || fetch(req).then(function (r) {
      if (r.ok) { var copy = r.clone(); caches.open(SHELL).then(function (c) { return c.put(req, copy); }); }
      return r;
    });
  });
}

// Map data. A tile downloaded in the last TILE_DAYS is reused without asking the network. An older one is
// downloaded again when it's next needed; if that fails or takes longer than TILE_WAIT_MS, the old copy is used.
// Copies older than TILE_DAYS are deleted only while new tiles are being saved, so an app that has been offline
// for a while keeps everything it had. The oldest also go first if there are more than TILE_MAX of them or the
// app's storage passes TILE_BYTES. The base map's style file, which names its current set of tiles, is shown
// from the copy straight away and checked with the network in the background.
var TILE_DAYS = 30, TILE_MAX = 6000, TILE_BYTES = 300 * 1024 * 1024, TILE_WAIT_MS = 4000, DAY = 86400000;
function savedAt(r) { return Number(r && r.headers.get('x-csc-cached')) || 0; }
var puts = 0;
function mapData(e, req, u) {
  var style = u.pathname.indexOf('/styles/') === 0;
  return caches.open(TILES).then(function (c) {
    return c.match(req).then(function (hit) {
      if (hit && !style && Date.now() - savedAt(hit) < TILE_DAYS * DAY) return hit;
      var net = fetch(req).then(function (r) {
        if (r.ok && r.type !== 'opaque') e.waitUntil(store(c, req, r.clone()));
        return r;
      });
      if (!hit) return net;
      e.waitUntil(net.catch(function () {}));
      if (style) return hit;
      // An expired tile: the fresh one if it comes in time, otherwise the old copy
      return new Promise(function (resolve) {
        var done = false, t = setTimeout(function () { finish(hit); }, TILE_WAIT_MS);
        function finish(r) { if (!done) { done = true; clearTimeout(t); resolve(r); } }
        net.then(function (r) { finish(r.ok ? r : hit); }, function () { finish(hit); });
      });
    });
  });
}
function store(c, req, r) {
  return r.blob().then(function (b) {
    var h = new Headers();
    ['content-type', 'cache-control', 'expires', 'last-modified'].forEach(function (k) { var v = r.headers.get(k); if (v) h.set(k, v); });
    h.set('x-csc-cached', String(Date.now()));
    return c.put(req, new Response(b, { status: r.status, statusText: r.statusText, headers: h }));
  }).then(function () {
    if (++puts % 100 === 1) return tidy(c);   // on the first save after the worker starts, then every 100
  }).catch(function () { /* storage full or unavailable: carry on without it */ });
}
// The cache lists tiles in the order they were saved (a re-saved tile moves to the end), so work from the front
function tidy(c) {
  return c.keys().then(function (keys) {
    var i = 0, cutoff = Date.now() - TILE_DAYS * DAY;
    function expired() {
      if (i >= keys.length) return;
      return c.match(keys[i]).then(function (r) {
        if (r && savedAt(r) >= cutoff) return;   // the first one still in date: everything after it is newer
        return c.delete(keys[i++]).then(expired);
      });
    }
    return Promise.resolve(expired()).then(function () {
      var drop = keys.slice(i, i + Math.max(0, keys.length - i - TILE_MAX));
      i += drop.length;
      return Promise.all(drop.map(function (k) { return c.delete(k); }));
    }).then(function () { return budget(c, keys, i); });
  });
}
function budget(c, keys, i) {
  var st = self.navigator && self.navigator.storage;
  if (!st || !st.estimate || i >= keys.length) return;
  return st.estimate().then(function (est) {
    if (!(est.usage > TILE_BYTES)) return;
    var drop = keys.slice(i, i + Math.max(50, Math.ceil((keys.length - i) / 10)));
    return Promise.all(drop.map(function (k) { return c.delete(k); })).then(function () { return budget(c, keys, i + drop.length); });
  });
}
