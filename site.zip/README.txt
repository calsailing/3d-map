Cal Sailing Club 3D Map - the website

Upload everything in this folder to the web server (the site's root, https://map.cal-sailing.org/), keeping the
folders. Built by build.py from csc-3d-map.html; to change the map, edit that file and run build.py again.

  index.html             the map page (light: the code is in js/)
  js/                    the map's code: areas, app, and map3d (the 3D extras, loaded after the map appears).
                         The names change with every build, so browsers never use an old copy.
  lib/                   the map library (MapLibre GL JS 5.24.0, BSD licence), with its version in the folder name
  places/                one page for each sailing area, hazard and club place, the lights, and an index
  sw.js                  offline support (service worker)
  manifest.webmanifest   the installed app's name, colours and icons
  icons, csc-logo.png    the app icons and the club logo shown in the panel (it links to www.cal-sailing.org)
  og-image.jpg           the picture shown when the map is shared on social media and in messages
  robots.txt, sitemap.xml, llms.txt   for search engines and AI assistants

Notes
- Serve it over https, or phones won't offer to install it and offline support won't run.
- Old files in js/ from earlier builds can be deleted, or left: nothing refers to them.
- The server settings in ../hosting/ make repeat visits faster (long caching for js/ and lib/). Use the one for
  your server.
- Links: https://map.cal-sailing.org/?place=<id> opens a place in the map (ids: novice, junior, senior-dinghy, senior-keelboat, cruising-dinghy, cruising-keelboat, csc, jdock, entrance, pier, ashby, reef, berkeley-reef-1, berkeley-marina-channel-2, berkeley-marina-channel-3, berkeley-breakwater-1, berkeley-breakwater-2, berkeley-north-breakwater-3, berkeley-north-breakwater-4, berkeley-marina-north, berkeley-marina-south, berkeley-breakwater-center, emeryville-marina-1, emeryville-marina-2, emeryville-marina-3, emeryville-marina-4, emeryville-marina-5, emeryville-marina-6, emeryville-marina-7, emeryville-marina-8).
